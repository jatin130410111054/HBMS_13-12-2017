package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.CustomerException;
import com.capgemini.hbms.util.DBConnection;

public class HotelDetailsDAOImpl implements IHotelDetailsDAO {

	@Override
	public List<HotelDetailsBean> viewHotels() throws CustomerException {
		HotelDetailsBean hotelDetailsBean;
		List<HotelDetailsBean> hotelsList = new ArrayList<HotelDetailsBean>();
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperHotelDetails.SHOW_HOTELS); // Preparing query
						){
			
			
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			while(rs.next())
			{
				String hotelId=rs.getString(1);
				String city=rs.getString(2);
				String hotelName=rs.getString(3);
				String address=rs.getString(4);
				String description=rs.getString(5);
				double avgRatePerNight=rs.getDouble(6);
				String phoneNo1=rs.getString(7);
				String phoneNo2=rs.getString(8);
				String rating=rs.getString(9);
				String email=rs.getString(10);
				String fax=rs.getString(11);
				/*hotel_id,city,hotel_name,address,description,avg_rate_per_night,phone_no1,phone_no2,rating,email,fax*/
				
				hotelDetailsBean = new HotelDetailsBean(hotelId,city,hotelName,address,description,avgRatePerNight,phoneNo1,phoneNo2,rating,email,fax);
				hotelsList.add(hotelDetailsBean);
			}
			
		} catch(SQLException sqlEx){
			throw new CustomerException(sqlEx.getMessage()); //Throws error
		}
		return hotelsList;
	}

	

	@Override
	public HotelDetailsBean viewHotel(String hotelId) throws CustomerException {
		
		HotelDetailsBean hotelDetailsBean = new HotelDetailsBean();;
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperHotelDetails.SHOW_HOTELDETAILS); // Preparing query
						){
			
			preparedStatement.setString(1, hotelId);
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			while(rs.next())
			{
				String hotelID=rs.getString(1);
				String city=rs.getString(2);
				String hotelName=rs.getString(3);
				String address=rs.getString(4);
				String description=rs.getString(5);
				double avgPerNightRate=rs.getDouble(6);
				String phoneNo1=rs.getString(7);
				String phoneNo2=rs.getString(8);
				String rating=rs.getString(9);
				String email=rs.getString(10);
				String fax=rs.getString(11);
				
				hotelDetailsBean = new HotelDetailsBean(hotelID,city,hotelName,address,description,avgPerNightRate,phoneNo1,phoneNo2,rating,email,fax);
			}
			
		} catch(SQLException sqlEx){
			throw new CustomerException(sqlEx.getMessage()); //Throws error
		}
		return hotelDetailsBean;
	}

}
