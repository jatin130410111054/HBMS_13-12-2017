package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.CustomerException;

public interface IBookingDetailsDAO {
	
	String bookHotelRoom(BookingDetailsBean bookingDetailsBean) throws CustomerException;
	
	boolean bookingStatus(String bookingId) throws CustomerException;
	
	BookingDetailsBean getBookingDetail(String bookingId) throws CustomerException;
}
