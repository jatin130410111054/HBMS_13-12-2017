package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.CustomerException;

public interface IHotelDetailsDAO {
	
	List<HotelDetailsBean> viewHotels() throws CustomerException;

	
	
	HotelDetailsBean viewHotel(String hotelId) throws CustomerException;

}
