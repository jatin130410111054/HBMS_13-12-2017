package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.CustomerException;

public interface IRoomDetailsDAO {

	boolean checkRoomAvailability(String roomId) throws CustomerException;
	
	List<String> getAllRoomIds() throws CustomerException;
	
	String getRoomRate(String roomId) throws CustomerException;
	
	List<RoomDetailsBean> getRoomHotelID() throws CustomerException;

	RoomDetailsBean getRoomDetail(String roomId) throws CustomerException;
	
	List<RoomDetailsBean> viewRooms(String hotelId) throws CustomerException;
}
