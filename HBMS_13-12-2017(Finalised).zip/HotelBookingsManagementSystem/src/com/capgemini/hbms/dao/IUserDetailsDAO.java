package com.capgemini.hbms.dao;

import java.util.List;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.CustomerException;

public interface IUserDetailsDAO {
	int RegisterUser(UserDetailsBean userDetails) 
			throws CustomerException;
	
	public List<UserDetailsBean> getUserCredentials()
			throws CustomerException;

	
	public UserDetailsBean getUserDetails(String userId)
			throws CustomerException;
}