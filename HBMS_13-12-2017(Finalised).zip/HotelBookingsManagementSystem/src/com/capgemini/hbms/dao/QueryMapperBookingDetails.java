package com.capgemini.hbms.dao;

public interface QueryMapperBookingDetails {

	public static final String INSERT_BOOKING_DETAILS = "INSERT INTO bookingdetails values(booking_id_sequence.nextval,?,?,?,?,?,?,?)";

	public static final String SHOW_BOOKINGID = "SELECT booking_id_sequence.CURRVAL FROM DUAL";

	public static final String GET_BOOKING_DETAIL = "SELECT * from bookingdetails WHERE booking_id = ?";
	
}
