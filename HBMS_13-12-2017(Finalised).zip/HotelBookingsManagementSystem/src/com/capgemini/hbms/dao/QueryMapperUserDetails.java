package com.capgemini.hbms.dao;

public interface QueryMapperUserDetails {
	
	public static final String REGISTER_CUSTOMER = "INSERT INTO users VALUES(user_id_sequence.nextval,?,?,?,?,?,?,?)";
	
	public static final String SHOW_USERID = "SELECT user_id_sequence.CURRVAL FROM DUAL";
	
	public static final String GET_USER_CREDENTIALS = "SELECT user_id,password,role FROM users";
	
	public static final String GET_USER_DETAILS = "SELECT * FROM users";
}