package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.CustomerException;
import com.capgemini.hbms.util.DBConnection;

public class UserDetailsDAOImpl implements IUserDetailsDAO {

	
	UserDetailsBean userDetailsBean = new UserDetailsBean();
	
	
	@Override
	public int RegisterUser(UserDetailsBean userDetails)
			throws CustomerException {
		
		int userId = 0;
		int records = 0;
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperUserDetails.REGISTER_CUSTOMER); // Preparing query
						){
			
			//Giving values to query  statement
			preparedStatement.setString(1, userDetails.getPassword());
			preparedStatement.setString(2, userDetails.getRole());
			preparedStatement.setString(3, userDetails.getUserName());
			preparedStatement.setString(4, userDetails.getMobile_no());
			preparedStatement.setString(5, userDetails.getPhone());
			preparedStatement.setString(6, userDetails.getAddress());
			preparedStatement.setString(7, userDetails.getEmail());

			
			records = preparedStatement.executeUpdate(); //Executing the query
			
			if(records>0){	 //Checking for the record retrieval
				;
			}
			else
			{
				throw new CustomerException();
			}
			
			PreparedStatement preparePatientID = 
					connPatient.prepareStatement(QueryMapperUserDetails.SHOW_USERID); //Preparing query
			
			ResultSet userIDrecord = preparePatientID.executeQuery(); //Execute query
			
			if(userIDrecord.next()){
				userId = userIDrecord.getInt(1); //Patient ID Retrieved
			}
		} catch(SQLException sqlEx){
			throw new CustomerException(sqlEx.getMessage()); //Throws error
		}
		
	return userId;
		
	}

	@Override
	public List<UserDetailsBean> getUserCredentials()
			throws CustomerException {
		
		
		List<UserDetailsBean> userCredentialsList = new ArrayList<UserDetailsBean>();
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperUserDetails.GET_USER_CREDENTIALS); // Preparing query
						){
			
			
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			
			while(rs.next())
			{
				String userId=rs.getString(1);
				String pass=rs.getString(2);
				String role=rs.getString(3);
				
				userDetailsBean = new UserDetailsBean(userId,pass,role);
				userCredentialsList.add(userDetailsBean);
			}
			
		} catch(SQLException sqlEx){
			throw new CustomerException(sqlEx.getMessage()); //Throws error
		}
		return userCredentialsList;
	}

	@Override
	public UserDetailsBean getUserDetails(String userId) throws CustomerException {
		
		List<UserDetailsBean> usersList = new ArrayList<UserDetailsBean>();
		
		try(Connection connPatient = DBConnection.getInstance().getConnection(); //DataBase Connection
				PreparedStatement preparedStatement=
						connPatient.prepareStatement(QueryMapperUserDetails.GET_USER_DETAILS); // Preparing query
						){
			ResultSet rs = preparedStatement.executeQuery(); //Executing the query
			
			while(rs.next())
			{
				userDetailsBean.setUserId(rs.getString(1));
				userDetailsBean.setPassword(rs.getString(2));
				userDetailsBean.setRole(rs.getString(3));
				userDetailsBean.setUserName(rs.getString(4));
				userDetailsBean.setMobile_no(rs.getString(5));
				userDetailsBean.setPhone(rs.getString(6));
				userDetailsBean.setAddress(rs.getString(7));
				userDetailsBean.setEmail(rs.getString(8));
			}

		} catch(SQLException sqlEx){
			throw new CustomerException(sqlEx.getMessage()); //Throws error
		}
		
		return userDetailsBean;
	}

}
