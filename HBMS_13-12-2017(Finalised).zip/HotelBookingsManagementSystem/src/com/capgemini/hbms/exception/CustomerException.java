package com.capgemini.hbms.exception;

public class CustomerException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7092283337963290590L;

	

	public CustomerException() {
		super();
	}



	public CustomerException(String message) {
		super(message);
	}

	
	
}
