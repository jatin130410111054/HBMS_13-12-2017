package com.capgemini.hbms.service;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.dao.BookingDetailsDAOImpl;
import com.capgemini.hbms.dao.IBookingDetailsDAO;
import com.capgemini.hbms.exception.CustomerException;

public class BookingServiceImpl implements IBookingService {

	IBookingDetailsDAO bookingDetailsDao = new BookingDetailsDAOImpl();
	
	@Override
	public BookingDetailsBean getBookingDetail(String bookingId) throws CustomerException {
		
		return bookingDetailsDao.getBookingDetail(bookingId);
	}

	@Override
	public boolean bookingStatus(String bookingId) throws CustomerException {
		// TODO Auto-generated method stub
		return false;
	}

	
	@Override
	public String bookHotelRoom(BookingDetailsBean bookingDetailsBean)
			throws CustomerException {
	
		return bookingDetailsDao.bookHotelRoom(bookingDetailsBean);
	}
}
