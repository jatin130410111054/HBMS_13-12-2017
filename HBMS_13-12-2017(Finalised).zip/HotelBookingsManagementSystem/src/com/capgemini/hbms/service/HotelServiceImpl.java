package com.capgemini.hbms.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.dao.BookingDetailsDAOImpl;
import com.capgemini.hbms.dao.HotelDetailsDAOImpl;
import com.capgemini.hbms.dao.IBookingDetailsDAO;
import com.capgemini.hbms.dao.IHotelDetailsDAO;
import com.capgemini.hbms.exception.CustomerException;

public class HotelServiceImpl implements IHotelService {

	IHotelDetailsDAO hotelDetailsDao = new HotelDetailsDAOImpl();
	IBookingDetailsDAO bookingDetailsDao = new BookingDetailsDAOImpl();
	
	@Override
	public List<HotelDetailsBean> viewHotels(String city) throws CustomerException {
		
		List<HotelDetailsBean> listOfHotels = hotelDetailsDao.viewHotels();
		List<HotelDetailsBean> hotelsBasedOnCity = new ArrayList<HotelDetailsBean>();
		
		for(HotelDetailsBean hotel : listOfHotels){
			if(hotel.getCity().equalsIgnoreCase(city)){
				hotelsBasedOnCity.add(hotel);
			}
		}
		return hotelsBasedOnCity;
	}

	@Override
	public List<HotelDetailsBean> viewHotels() throws CustomerException {
		return hotelDetailsDao.viewHotels();
	}

	@Override
	public HotelDetailsBean viewHotel(String hotelId) throws CustomerException {
		
		return hotelDetailsDao.viewHotel(hotelId);
	}
	

}
