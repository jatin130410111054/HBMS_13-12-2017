package com.capgemini.hbms.service;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.exception.CustomerException;

public interface IBookingService {

	BookingDetailsBean getBookingDetail(String bookingId) throws CustomerException;
	
	String bookHotelRoom(BookingDetailsBean bookingDetailsBean) throws CustomerException;
	
	boolean bookingStatus(String bookingId) throws CustomerException;
}
