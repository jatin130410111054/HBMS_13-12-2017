package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.CustomerException;

public interface IHotelService {

	public List<HotelDetailsBean> viewHotels(String city) throws CustomerException;

	HotelDetailsBean viewHotel(String hotelId) throws CustomerException;

	List<HotelDetailsBean> viewHotels() throws CustomerException;
}
