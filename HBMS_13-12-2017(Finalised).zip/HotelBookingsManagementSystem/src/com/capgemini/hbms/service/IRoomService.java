package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.exception.CustomerException;

public interface IRoomService {

	RoomDetailsBean getRoomDetail(String roomId) throws CustomerException;
	
	boolean checkRoomAvailability(String roomId) throws CustomerException;
	
	boolean isRoomIdValid(String roomId, String hotelId) throws CustomerException;
	
	public String getRoomRate(String roomId) throws CustomerException;
	
	List<RoomDetailsBean> viewRooms(String hotelId) throws CustomerException;
}
