package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.CustomerException;

public interface IUserService {

	int RegisterUser(UserDetailsBean userDetails) throws CustomerException;
	
	boolean LoginCheck(UserDetailsBean userDetails) throws CustomerException;

	public UserDetailsBean getUserDetails(String userId)
			throws CustomerException;
}
/*
register(insert into users)
loginsearch(credentials)
search(hotel)
insert(bookingdetails)
view/check(bookking id)*/