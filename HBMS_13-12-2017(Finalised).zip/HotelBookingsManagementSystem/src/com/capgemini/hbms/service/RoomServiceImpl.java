package com.capgemini.hbms.service;

import java.util.List;

import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.dao.IRoomDetailsDAO;
import com.capgemini.hbms.dao.RoomDetailsDAOImpl;
import com.capgemini.hbms.exception.CustomerException;

public class RoomServiceImpl implements IRoomService {

	IRoomDetailsDAO roomDetailsDao = new RoomDetailsDAOImpl();
	@Override
	public RoomDetailsBean getRoomDetail(String roomId) throws CustomerException {
		
		return roomDetailsDao.getRoomDetail(roomId);
	}
	
	@Override
	public boolean checkRoomAvailability(String roomId)
			throws CustomerException {
		
		return roomDetailsDao.checkRoomAvailability(roomId);
		
	}

	@Override
	public boolean isRoomIdValid(String roomId, String hotelId) throws CustomerException {
		
		boolean roomIdFound = false;
		List<RoomDetailsBean> roomIdList;
		int flag = 1;
		try {
			roomIdList = roomDetailsDao.getRoomHotelID();

			for(RoomDetailsBean roomHotelID : roomIdList){
				if(roomHotelID.getRoomId().equals(roomId)&&roomHotelID.getHotelId().equals(hotelId)){
					roomIdFound = true;
					break;
				}
			}

			
		} catch (CustomerException e) {
			System.out.println("Rooms couldnt be found");
			e.printStackTrace();
		}
			
		return roomIdFound;
	}

	@Override
	public String getRoomRate(String roomId) throws CustomerException {
		
		return roomDetailsDao.getRoomRate(roomId);
	}

	@Override
	public List<RoomDetailsBean> viewRooms(String hotelId) throws CustomerException {
		
		return roomDetailsDao.viewRooms(hotelId);
	}

}
