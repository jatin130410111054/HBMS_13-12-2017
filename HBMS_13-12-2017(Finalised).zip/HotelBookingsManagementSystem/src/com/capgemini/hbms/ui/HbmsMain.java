package com.capgemini.hbms.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.time.temporal.TemporalAccessor;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.hbms.bean.BookingDetailsBean;
import com.capgemini.hbms.bean.HotelDetailsBean;
import com.capgemini.hbms.bean.RoomDetailsBean;
import com.capgemini.hbms.bean.UserDetailsBean;
import com.capgemini.hbms.exception.CustomerException;
import com.capgemini.hbms.service.BookingServiceImpl;
import com.capgemini.hbms.service.HotelServiceImpl;
import com.capgemini.hbms.service.IBookingService;
import com.capgemini.hbms.service.IHotelService;
import com.capgemini.hbms.service.IRoomService;
import com.capgemini.hbms.service.IUserService;
import com.capgemini.hbms.service.RoomServiceImpl;
import com.capgemini.hbms.service.UserServiceImpl;

public class HbmsMain {
	
	private String password;
	private String userName;
	private String mobileNo;
	private String phone;
	private String address;
	private String email;
	
	private String bookingId;
	private LocalDate bookedFrom;
	private LocalDate bookedTo;
	private int noOfAdults;
	private int noOfChildren;
	private double amount;
	
	
	
	/*booked_from date, booked_to date, 
	no_of_adults number(6,2), no_of_children number(6,2)*/
	
	
	UserDetailsBean userDetailsBean = new UserDetailsBean();
	HotelDetailsBean hotelDetailsBean = new HotelDetailsBean();
	BookingDetailsBean bookingDetailsBean = new BookingDetailsBean();
	
	IHotelService hotelService = new HotelServiceImpl();
	IUserService userService = new UserServiceImpl();
	IRoomService roomService = new RoomServiceImpl();
	IBookingService bookingService = new BookingServiceImpl();
	
	public static void main(String[] args) {
		
		String role;
		boolean valid = false;
		String choiceHBMS;
		
		Scanner scInput = new Scanner(System.in);
		
		while(true){
			
			System.out.println("------------------------\n\nHOTEL MANAGEMENT SYSTEM\n\n------------------------");
			System.out.println("\n\n\n1.Admin\n2.Employee\n3.Customer\n\n");
			
			choiceHBMS = scInput.nextLine();
			
			//CHOICE of ADMIN, EMPLOYEE, CUSTOMER
			switch(choiceHBMS){
			
				case "1" :
//==============================================ADMIN==============================================================					
							role = "Admin";
							
							break;
//==============================================EOF ADMIN===================================================================					
				case "2" : 
//==============================================EMPLOYEE===========================================================
							role = "Employee";
							
							break;
//==============================================EOF EMPLOYEE===================================================================							
				case "3" :
//==============================================CUSTOMER===========================================================
							CustomerMain customerMain = new CustomerMain();
							customerMain.main();
							break;
//===================================================EOF CUSTOMER==============================================================			
							
				default : 
							System.out.println("Entered choice is incorrect. Please select a valid number!!\n\n");
							break;
			
			
			}
			
			
			
		}

	}
	
	public Object Register(String role){
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.print("Enter UserName : ");
		userName = scInput.nextLine();
		System.out.print("Enter Password : ");
		password = scInput.nextLine();
		System.out.print("Enter Mobile Number : ");
		mobileNo = scInput.nextLine();
		System.out.print("Enter Phone Number : ");
		phone = scInput.nextLine();
		System.out.print("Enter Address : ");
		address = scInput.nextLine();
		System.out.print("Enter Email : ");
		email = scInput.nextLine();
		
		userDetailsBean = new UserDetailsBean(userName,password,role,mobileNo,phone,address,email);
		return userDetailsBean;
	}
	
	public String Book(String roomId,String userId) throws CustomerException{
		
		Scanner scInput = new Scanner(System.in);
		
		System.out.println("\n-----------------------\nEnter Booking Details\n-----------------------\n\n");
		System.out.print("From Date (dd/MM/yyyy)    : ");
		String bookF = scInput.nextLine();
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		TemporalAccessor ta1 = dtf.parse(bookF);
		LocalDate bookFrom = LocalDate.from(ta1);

		System.out.print("To Date (dd/MM/yyyy)      : ");
		String bookT = scInput.nextLine();
		
		TemporalAccessor ta2 = dtf.parse(bookT);
		LocalDate bookTo = LocalDate.from(ta2);
		
		
		System.out.print("Enter the no. of adults   : ");
		noOfAdults = scInput.nextInt();
		scInput.nextLine();
		
		System.out.print("Enter the no. of children : ");
		noOfChildren = scInput.nextInt();
		scInput.nextLine();
		
		long daysBetween = ChronoUnit.DAYS.between(bookFrom, bookTo);
		
		String ratePerNight = roomService.getRoomRate(roomId);
		int rate = Integer.parseInt(ratePerNight);
		
		amount = daysBetween * rate;
		
		
		bookingDetailsBean.setUserId(userId);
		bookingDetailsBean.setRoomId(roomId);
		bookingDetailsBean.setBookedFrom(bookFrom);
		bookingDetailsBean.setBookedTo(bookTo);
		bookingDetailsBean.setNoOfAdults(noOfAdults);
		bookingDetailsBean.setNoOfChildren(noOfChildren);
		bookingDetailsBean.setAmount(amount);
		
		bookingId = bookingService.bookHotelRoom(bookingDetailsBean);
		
		System.out.println("\n\nHotel Booked Successfully!!!!\n\nYour Booking Id is " + bookingId + "\n");
		
		return bookingId;
	}
	
	
	
	public int HotelSearch(String city){
		int index = 0;
		try {
			List<HotelDetailsBean> hotelsList = hotelService.viewHotels(city);
			
			if(hotelsList.isEmpty()){
				;
			}else{
				
				
				System.out.println("\n\nHotels List\n");
				
				System.out.println("Hotel ID      City      Hotel Name      Address      Description      Average Rate Per Night      PhoneNo 1      PhoneNo2      Rating      Email      Fax\n");
				
				for(HotelDetailsBean hotel : hotelsList){
					
					++index;
					System.out.println(hotel.getHotelId() + "           " + hotel.getCity() + "     " + hotel.getHotelname() + "      " + hotel.getAddress() + "      " + hotel.getDescription() + "              " + hotel.getAvgRatePerNight() + "             " + hotel.getPhoneNo1() + "      " + hotel.getPhoneNo2() + "      " + hotel.getRating() + "      " + hotel.getEmail() + "      " + hotel.getFax());
				}
				
				System.out.println("\nTotal Hotels found : " + index + "\n\n");
			}
		} catch (CustomerException e) {
			System.out.println("\nDue to some reason Hotel lists are not available");
			e.printStackTrace();
		}
		return index;
	}
	
	public boolean viewHotelRooms(String hotelId){
		
		boolean found = false;
		
		try {
			List<RoomDetailsBean> roomDetails = roomService.viewRooms(hotelId);
			
			if(roomDetails.isEmpty()){
				System.out.println("\nEnter a valid Hotel ID\n");
			}else{
				System.out.println("\n\nRoom details for Hotel ID : " + hotelId);
				
				System.out.println("Hotel ID       Room ID         Room No      Room Type     Per Night Rate      Availability\n");
				for(RoomDetailsBean roomDetail : roomDetails){
					
					if(roomDetail.getRoomType().equals("AC")){
						System.out.println(roomDetail.getHotelId() + "             " + roomDetail.getRoomId() + "            " + roomDetail.getRoomNo() + "             " + roomDetail.getRoomType() + "               " + roomDetail.getPerNightRate() + "             " + roomDetail.getAvailability());
					}else{
						System.out.println(roomDetail.getHotelId() + "             " + roomDetail.getRoomId() + "            " + roomDetail.getRoomNo() + "             " + roomDetail.getRoomType() + "           " + roomDetail.getPerNightRate() + "             " + roomDetail.getAvailability());
					}
					
				}
				found = true;
			}
			
		} catch (CustomerException e) {
			System.out.println("No rooms available");
			e.printStackTrace();
		}
		return found;
	}
	
	public List<String> viewCities(){
		
		List<HotelDetailsBean> listOfHotels;
		List<String> repeatedCities = new ArrayList<String>();
		List<String> cities = new ArrayList<String>();
		int flag = 1;
		try {
			listOfHotels = hotelService.viewHotels();

			for(HotelDetailsBean hotel : listOfHotels){
				repeatedCities.add(hotel.getCity());
				}

			for(String city : repeatedCities){

				if(cities.isEmpty()){
					cities.add(city);
				}
				else{
					
					for(String cityCheck : cities){
						
						if(city.matches(cityCheck)){
							flag=0;
						}	
					}
					if(flag==1){
						cities.add(city);
					}
					flag = 1;
				}
			}
		} catch (CustomerException e) {
			System.out.println("Cities couldnt be retrived");
			e.printStackTrace();
		}
			
		return cities;
	}
}
